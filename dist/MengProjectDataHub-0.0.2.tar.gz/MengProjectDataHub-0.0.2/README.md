Meng Project
This lib is used to manipulate the data in the HitachiFiles and is the crucial basement for the following Machinelearning stuff.
